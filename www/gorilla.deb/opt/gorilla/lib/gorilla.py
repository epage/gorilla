#!/usr/bin/env python
# -*- coding: utf-8 -*-


import sys


sys.path.append("/opt/gorilla/lib")


import gorilla_pygame


if __name__ == "__main__":
	gorilla_pygame.main()
